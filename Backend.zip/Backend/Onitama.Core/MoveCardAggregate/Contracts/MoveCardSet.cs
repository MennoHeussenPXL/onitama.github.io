﻿namespace Onitama.Core.MoveCardAggregate.Contracts;

public enum MoveCardSet
{
    Original,
    SenseisPath,
}