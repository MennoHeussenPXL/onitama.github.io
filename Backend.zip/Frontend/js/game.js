document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const info = urlParams.get('info');
    var message = document.getElementById("message")
    if (info == "start") {
        message.textContent = "Waiting for Players..."
    } else {
        message.textContent = "Waiting for party leader to start game..."
    }
    document.getElementById('leave').addEventListener('click', function (event) {
        fetch('https://localhost:5051/api/Tables/{id}/leave', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
        },
        body: JSON.stringify(formDataJSON),
        })
        .then(response => {
            if (!response.ok) {
                return response.json()
            } else {
                console.log('registerd')
                window.location.href = 'index.html?email=' + encodeURIComponent(email);
            };
        }).then(data => {
            console.log(data.message);
            errorMessageContainer.textContent = data.message;
        });
    });
    /*var overlay = document.getElementById("overlay");
    while (data.hasAvailableSeat) {
        overlay.style.display = "flex";
    }
    overlay.style.display = "none";*/
    /*fetch('https://localhost:5051/api/Authentication/register', {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
        },
        body: JSON.stringify(formDataJSON),
    })
    .then(response => {
        if (!response.ok) {
            return response.json()
        } else {
            console.log('registerd')
            window.location.href = 'index.html?email=' + encodeURIComponent(email);
        };
    }).then(data => {
        console.log(data.message);
        errorMessageContainer.textContent = data.message;
    });*/
});