document.addEventListener('DOMContentLoaded', function () {
    var scrollableList = document.getElementById("scrollable-list");
    var selectedElement = null;
    fetch('https://localhost:5051/api/Tables/with-available-seats', {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
        }
    }).then(response => {
        if (!response.ok) {
            return;
        } else {
            return response.json();
        }
    }).then(data => {
        console.log(data);
        scrollableList.innerHTML = "";
        data.forEach(function (item) {
            var listItem = document.createElement("div");
            var ownerPlayer;
            var seatedPlayers = "";
            item.seatedPlayers.forEach(function (player) {
                seatedPlayers += " " + player.name;
                if (player.id == item.ownerPlayerId) {
                    ownerPlayer = player.name;
                }
            })
            listItem.textContent = "owner = " + ownerPlayer + ", players =" + seatedPlayers;
            listItem.classList.add("list-item");
            listItem.setAttribute("id", item.id);
            scrollableList.appendChild(listItem);
    });
    function clearSelection() {
        if (selectedElement) {
            selectedElement.classList.remove("selected");
            selectedElement = null;
        }
    }
    function handleItemClick(event) {
        clearSelection(); // Clear previous selection
        var clickedElement = event.target;
        clickedElement.classList.add("selected");
        selectedElement = clickedElement;
    }   
    var listItems = scrollableList.getElementsByClassName("list-item");
    for (var i = 0; i < listItems.length; i++) {
        listItems[i].addEventListener("click", handleItemClick);
    }
    document.getElementById('button3').addEventListener('click', function (event) {
        const DataJSON = {
            "numberOfPlayers": 2,
            "playerMatSize": 5,
            "moveCardSet": 0
        }
        fetch('https://localhost:5051/api/Tables', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + sessionStorage.getItem("token")
            },
            body: JSON.stringify(DataJSON),
        }).then(response => {
            if (!response.ok) {
                return response.json();
            } else {
                window.location.href = 'game.html?info=' + encodeURIComponent("start");
                return response.json();
            }
        }).then(data => {
            console.log(data);
        });
    });
    document.getElementById('button4').addEventListener('click', function (event) {
        if (selectedElement) {
            var tableId = selectedElement.getAttribute("id");
            const DataJSON = {
                id: tableId
            }
            fetch('https://localhost:5051/api/Tables/' + tableId + '/join', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + sessionStorage.getItem("token")
                },
                body: JSON.stringify(DataJSON),
            }).then(response => {
                if (!response.ok) {
                    return response.json();
                } else {
                    window.location.href = 'game.html?info=' + encodeURIComponent("join");
                    return response.json();
                }
            }).then(data => {
                console.log(data);
                sessionStorage.setItem("tableId", data)
            });
        } else {
            console.log("No element selected.");
        }
        });
    });
});