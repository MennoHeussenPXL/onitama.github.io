﻿namespace Onitama.Core.SchoolAggregate.Contracts;

public enum PawnType
{
    Master,
    Student
}