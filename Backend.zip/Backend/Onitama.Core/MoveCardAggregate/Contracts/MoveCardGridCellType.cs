﻿namespace Onitama.Core.MoveCardAggregate.Contracts;

public enum MoveCardGridCellType
{
    Empty = 0,
    Target = 1,
    Start = 2
}