﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Onitama.Bootstrapper")]
[assembly: InternalsVisibleTo("Onitama.Api.Tests")]
[assembly: InternalsVisibleTo("Onitama.Infrastructure.Tests")]