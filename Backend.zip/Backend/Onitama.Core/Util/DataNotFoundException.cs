﻿namespace Onitama.Core.Util;

public class DataNotFoundException : Exception
{
}