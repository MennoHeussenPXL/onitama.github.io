﻿namespace Onitama.Api.Models.Input;

public class SkipMovementModel
{
    public string MoveCardName { get; set; }
}