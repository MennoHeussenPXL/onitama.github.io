﻿namespace Onitama.Api.Models.Output;

public class AccessPassModel
{
    public UserModel User { get; set; }
    public string Token { get; set; }
}